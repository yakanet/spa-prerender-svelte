import{b as r}from"../chunks/i18n-util.c37db97b.js";import{R as t}from"../chunks/control.f5b05b5f.js";function n(e,o){return new t(e,o.toString())}new TextEncoder;const a=async()=>{throw n(302,`/${r}/`)},l=Object.freeze(Object.defineProperty({__proto__:null,load:a},Symbol.toStringTag,{value:"Module"}));export{l as universal};
//# sourceMappingURL=2.96455e1b.js.map
