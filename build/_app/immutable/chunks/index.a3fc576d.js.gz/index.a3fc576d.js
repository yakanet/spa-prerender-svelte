const e={hi:"Hi {name:string}!",search:"Search"};export{e as default};
//# sourceMappingURL=index.a3fc576d.js.map
