const e={title:"Welcome to SvelteKit",hi:"Hi {name:string}!",search:"Search",restaurants:"Restaurants",products:"Products",open:"Open",close:"Close",pwa_new_content:"New content available, click on reload button to update.",pwa_reload:"Reload",pwa_close:"Close"};export{e as default};
//# sourceMappingURL=index.5827e914.js.map
