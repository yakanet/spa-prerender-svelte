const e={hi:"Bonjour {name}! Merci de mettre une étoile si vous aimez ce projet",search:"Rechercher"};export{e as default};
//# sourceMappingURL=index.87f1577a.js.map
