const e={hi:"Bonjour {name}!",search:"Rechercher"};export{e as default};
//# sourceMappingURL=index.5f0b5eff.js.map
