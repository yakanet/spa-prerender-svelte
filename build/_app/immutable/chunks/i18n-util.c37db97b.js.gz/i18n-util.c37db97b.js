const o="fr",a=["en","fr"],e=s=>a.includes(s),c={},l={};export{c as a,o as b,e as i,l};
//# sourceMappingURL=i18n-util.c37db97b.js.map
