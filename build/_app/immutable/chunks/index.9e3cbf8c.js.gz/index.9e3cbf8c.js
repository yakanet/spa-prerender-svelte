const e={hi:"Hi {name:string}! Please leave a star if you like this project",search:"Search"};export{e as default};
//# sourceMappingURL=index.9e3cbf8c.js.map
